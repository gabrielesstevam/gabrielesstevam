#=================================================================================
#=================================================================================
import def_main #importa arquivo de funções
import os #importa sistema
#=================================================================================
#=================================================================================
lista_contas = []
lista_alunos = []
conta_logada = {}
id_aluno = 45536
id_conta = 234
senha_geren = 125689
inicio = True
#=================================================================================
#=================================================================================
while True:
    opc_conta, inicio = def_main.menu_conta(inicio)
    if opc_conta == 3:
        os.system('cls')
        print('Programa Encerrado')
        break
    elif opc_conta == 1: #CADASTRAR UMA CONTA
        cadastro, id_conta = def_main.cadastrar_conta(id_conta) 
        lista_contas.append(cadastro)
        os.system('cls')
        print('Conta cadastrada')
        continue
    elif opc_conta == 2: #LOGAR NA CONTA    
        if not lista_contas:
            os.system('cls')
            print('Não tem contas cadastradas para logar. Cadastre uma conta')
            continue
        logout, conta_logada = def_main.logar_conta(lista_contas)
        if logout:
            while True:
                opc = def_main.menu_gerencia()
                if opc == 1: #CADASTRAR ALUNO
                    while True:
                        cadastro_aluno, id_aluno = def_main.cadastrar_aluno(id_aluno)
                        lista_alunos.append(cadastro_aluno)
                        os.system('cls')
                        print('Aluno cadastrado')
                        opc_cad_aluno = str(input('Deseja cadastrar mais alunos? (S/N):'))
                        if opc_cad_aluno.upper() not in ['S','N']:
                            os.system('cls')
                            print('Opção inválida. Tente novamente')
                            break
                        else:
                            if opc_cad_aluno.upper() == 'S':
                                continue
                            elif opc_cad_aluno.upper() == 'N':
                                break
                if opc == 2: #LISTAR ALUNOS
                    if not lista_alunos:
                        os.system('cls')
                        print('Lista Vazia. Por favor cadastre algum aluno')
                        continue
                    else:
                        def_main.listar_aluno(lista_alunos)
                elif opc == 3: #DELETAR ALUNOS
                    if not lista_alunos:
                        os.system('cls')
                        print('Lista Vazia. Por favor cadastre algum aluno')
                        continue
                    else:
                        def_main.deletar_aluno(lista_alunos)
                elif opc == 4: #LISTAR CONTAS
                    if not lista_contas:
                        os.system('cls')
                        print('Lista Vazia. Por favor cadastre alguma conta')
                        continue
                    else:
                        def_main.listar_conta(lista_contas)
                elif opc == 5: #DELETAR CONTAS
                    if not lista_contas:
                        os.system('cls')
                        print('Lista Vazia. Por favor cadastre alguma conta')
                        continue
                    else:
                        conta_deletada = def_main.deletar_conta(lista_contas, senha_geren, conta_logada)
                        if conta_deletada:
                            break
                elif opc == 6:
                    os.system('cls')
                    print('Deslogado da conta')
                    break
                    