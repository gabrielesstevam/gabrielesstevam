import os #importa sistema
#=================================================================================
#=================================================================================
def menu_conta(ini):
    if ini:
        os.system('cls')
        ini = False
    while True:
        print('-'*56)
        print('-'*15, 'SISTEMA ONLINE DE ENSINO', '-'*15)
        print('-'*56)
        print('1 - Cadastrar nova conta')
        print('2 - Logar em conta existente')
        print('3 - Encerrar Programa')
        try:
            opc = int(input('>>> '))
        except ValueError:
            os.system('cls')
            print('Número inválido. Insira um número inteiro')
            continue
        if opc not in [1, 2, 3]:
            os.system('cls')
            print('Opção inválida. Insira uma das opções.')
            continue
        else:
            if opc == 1:
                return 1, ini
            elif opc == 2:
                return 2, ini
            elif opc == 3:
                return 3, ini
#=================================================================================
#=================================================================================
def cadastrar_conta(id):
    os.system('cls')
    while True:
        print('-'*56)
        print('-'*18, 'CADASTRO DE CONTAS', '-'*18)
        print('-'*56)
        id += 1
        name = str(input('Digite o nome do usuário: '))
        if len(name) < 5 or len(name) > 14:
            os.system('cls')
            print('O nome de usuário tem que ter no mínimo 6 dígitos, e no maximo 14. Tente novamente')
            continue
        senha = str(input('Digite a senha: '))
        if len(senha) < 5:
            os.system('cls')
            print('A senha tem que ter no mínimo 6 dígitos. Tente novamente')
            continue
        senha_conf = input('Digite a senha novamente para confirmar: ')
        if not senha_conf == senha:
            os.system('cls')
            print('As senhas não estão iguais. Tente novamente')
            continue
        if senha_conf == senha:
            cadastro = {'id' : id, 'nome': name,'senha': senha}
            return cadastro, id
#=================================================================================
#=================================================================================
def logar_conta(lista_contas):
    os.system('cls')
    while True:
        print('-'*56)
        print('-'*15, 'lOGAR', '-'*15)
        print('-'*56)  
        encontrado = False
        name = input('Digite o nome do usuário: ')
        senha = input('Digite a senha: ')
        for i in lista_contas:
            if i['nome'] == name and i['senha'] == senha:
                os.system('cls')
                print('Conta logada com sucesso')
                encontrado = True
                return encontrado, i
        if not encontrado:
            os.system('cls')
            print("O nome de usuário ou a senha esta incorreta")
#=================================================================================
#=================================================================================
def menu_gerencia():
    os.system('cls')
    while True:
        print('-'*56)
        print('-'*15, 'GERENCIA DE CADASTROS', '-'*15)
        print('-'*56)
        print('Qual opção você deseja?')
        print('1 - Cadastrar novo aluno')
        print('2 - Listar cadastros dos alunos')
        print('3 - Deletar cadastro de aluno')
        print('4 - Listar cadastro de contas')
        print('5 - Deletar cadastro de conta')
        print('6 - Deslogar da conta')
        try:
            opc = int(input('>>> '))
        except ValueError:
            os.system('cls')
            print('Número inválido. Digite um número inteiro')
            continue
        if opc not in [1, 2, 3, 4, 5, 6]:
            os.system('cls')
            print('Opção Inválida. Digite uma das opções')
        return opc
#=================================================================================
#=================================================================================
def cadastrar_aluno(id):
    os.system('cls')
    while True:
        print('-'*56)
        print('-'*15, 'CADASTRO DE ALUNO', '-'*15)
        print('-'*56)  
        id =+ 1
        name = str(input('Nome: '))
        try:
            idade = int(input('Idade: '))
        except ValueError:
            os.system('cls')
            print('Digite um número inteiro')
            continue
        if idade < 17:
            os.system('cls')
            print('Idade muito baixa para curso. Tente Novamente')
        curso = str(input('Curso: '))
        while True:
            print('Instituição utilizada: ')
            print('- RN')
            print('- PB')
            print('- MG')
            print('- RS')
            print('- SP')
            try:
                polo = str(input('>>> '))
            except:
                os.system('cls')
                print('Digite alguma coisa por favor')
            if polo.upper() not in ['RN','PB','MG','RS','SP']:
                os.system('cls')
                print('Digite uma das opções por favor')
                continue
            else: 
                break
        cadastro = {'id' : id,'nome':name,'idade':idade,'curso':curso,'polo':polo}
        return cadastro, id
#=================================================================================
#=================================================================================
def listar_aluno(lista):
    os.system('cls')
    while True:
        print('-'*56)
        print('-'*15, 'lISTAGEM DE ALUNO', '-'*15)
        print('-'*56)  
        id_en = False
        nome_en = False
        idade_en = False
        curso_en = False
        polo_en = False
        
        print('Qual método de procura deseja utilizar?: ')
        print('1- Listar por id')
        print('2- Listar por nome')
        print('3- Listar por idade')
        print('4- Listar por curso')
        print('5- Listar por polos')
        print('6- Listar todos os alunos cadastrados')
        print('7- Voltar ao menu de gerenciamento')
        try:
            opc = int(input('>>> '))
        except ValueError:
            os.system('cls')
            print('Número inválido. Digite um número inteiro')
        if opc not in [1,2,3,4,5,6,7]:
            os.system('cls')
            print('Digite uma das opções por favor')
            continue
        else:
            if opc == 7:
                break
            elif opc == 1: #LISTAR POR ID
                try:
                    opc_id = int(input('Digite o id do aluno que deseja encontrar: '))
                except ValueError:
                    os.system('cls')
                    print('Número inválido. Digite números inteiros')
                    continue
                os.system('cls')
                for i in lista:
                    if i['id'] == opc_id:
                        print('-'*56)
                        print('Id:', i['id'])
                        print('Nome:', i['nome'])
                        print('Idade:', i['idade'])
                        print('Curso:', i['curso'])
                        print('Polo:', i['polo'])
                        id_en = True
                if not id_en:
                        os.system('cls')
                        print('Id não encontrado. Tente Novamente')
                        continue
            elif opc == 2:#LISTAR POR NOME
                opc_nome = str(input('Digite o nome do aluno que deseja encontrar: '))
                os.system('cls')
                for i in lista:
                    if i['nome'] == opc_nome:
                        print('-'*56)
                        print('Id:', i['id'])
                        print('Nome:', i['nome'])
                        print('Idade:', i['idade'])
                        print('Curso:', i['curso'])
                        print('Polo:', i['polo'])
                        nome_en = True
                if not nome_en:
                        os.system('cls')
                        print('Nome não encontrado. Tente Novamente')
                        continue
            elif opc == 3:#LISTAR POR IDADE
                try:
                    opc_idade = int(input('Digite a idade do aluno que deseja encontrar: '))
                except ValueError:
                    os.system('cls')
                    print('Número inválido. Digite números inteiros')
                    continue
                os.system('cls')
                for i in lista:
                    if i['idade'] == opc_idade:
                        print('-'*56)
                        print('Id:', i['id'])
                        print('Nome:', i['nome'])
                        print('Idade:', i['idade'])
                        print('Curso:', i['curso'])
                        print('Polo:', i['polo'])
                        idade_en = True
                if not idade_en:
                        os.system('cls')
                        print('O aluno com esta idade não foi encontrado. Tente Novamente')
                        continue
            elif opc == 4:#LISTAR POR CURSO
                opc_curso = str(input('Digite o curso do aluno que deseja encontrar: '))
                os.system('cls')
                for i in lista:
                    if i['curso'] == opc_curso:
                        print('-'*56)
                        print('Id:', i['id'])
                        print('Nome:', i['nome'])
                        print('Idade:', i['idade'])
                        print('Curso:', i['curso'])
                        print('Polo:', i['polo'])
                        curso_en = True
                if not curso_en:
                        os.system('cls')
                        print('O aluno com este curso não foi encontrado. Tente Novamente')
                        continue
            elif opc == 5:#LISTAR POR POLO
                opc_polo = str(input('Digite o polo do aluno que deseja encontrar: '))
                os.system('cls')
                for i in lista:
                    if i['polo'] == opc_polo:
                        print('-'*56)
                        print('Id:', i['id'])
                        print('Nome:', i['nome'])
                        print('Idade:', i['idade'])
                        print('Curso:', i['curso'])
                        print('Polo:', i['polo'])
                        polo_en = True
                if not polo_en:
                        os.system('cls')
                        print('O aluno com este polo não foi encontrado. Tente Novamente')
                        continue
            elif opc == 6:#LISTAR TODOS
                os.system('cls')
                for i in lista:
                    print('-'*56)
                    print('Id:', i['id'])
                    print('Nome:', i['nome'])
                    print('Idade:', i['idade'])
                    print('Curso:', i['curso'])
                    print('Polo:', i['polo'])
#=================================================================================
#=================================================================================
def listar_conta(lista):
    os.system('cls')
    while True:
        print('-'*56)
        print('-'*15, 'lISTAGEM DE CONTAS', '-'*15)
        print('-'*56)  
        id_en = False
        nome_en = False

        print('Qual método de procura deseja utilizar?: ')
        print('1- Listar por id')
        print('2- Listar por nome')
        print('3- Listar todos as contas cadastradas')
        print('4- Voltar ao menu de gerenciamento')
        try:
            opc = int(input('>>> '))
        except ValueError:
            os.system('cls')
            print('Número inválido. Digite um número inteiro')
        if opc not in [1,2,3,4]:
            os.system('cls')
            print('Digite uma das opções por favor')
            continue
        else:
            if opc == 4:
                break
            elif opc == 1: #LISTAR POR ID
                try:
                    opc_id = int(input('Digite o id da conta que deseja encontrar: '))
                except ValueError:
                    os.system('cls')
                    print('Número inválido. Digite números inteiros')
                    continue
                for i in lista:
                    if i['id'] == opc_id:
                        print('-'*56)
                        print('Id:', i['id'])
                        print('Nome:', i['nome'])
                        id_en = True
                if not id_en:
                        os.system('cls')
                        print('Id não encontrado. Tente Novamente')
                        continue
            elif opc == 2:#LISTAR POR NOME
                opc_nome = str(input('Digite o nome de usuário que deseja encontrar: '))
                for i in lista:
                    if i['nome'] == opc_nome:
                        print('-'*56)
                        print('Id:', i['id'])
                        print('Nome:', i['nome'])
                        nome_en = True
                if not nome_en:
                        os.system('cls')
                        print('Nome não encontrado. Tente Novamente')
                        continue
            elif opc == 6:#LISTAR TODOS
                for i in lista:
                    print('Id:', i['id'])
                    print('Nome:', i['nome'])
#=================================================================================
#=================================================================================
def deletar_conta(lista, senha, log):
    os.system('cls')
    while True:
        print('-'*56)
        print('-'*15, 'GERÊNCIAMENTO DE CONTAS', '-'*15)
        print('-'*56)  
        senha_corr = int(input('Digite a senha de gerenciamento: '))
        if senha_corr == senha:
            print('-'*56) 
            print('Qual método deseja utilizar para deletar?: ')
            print('1- Deletar a conta por id')
            print('2- Deletar todos as contas cadastrados de um vez')
            print('3- Voltar ao menu de gerenciamento')
            try:
                opc = int(input('>>> '))
            except ValueError:
                os.system('cls')
                print('Número inválido. Digite um número inteiro')
            if opc not in [1,2,3]:
                os.system('cls')
                print('Digite uma das opções por favor')
                continue
            else:
                if opc == 3:
                    break
                elif opc == 2:
                    for i in lista:
                        print('-'*56) 
                        print('Id:', i['id'])
                        print('Nome:', i['nome'])
                        if i == log:
                            os.system('cls')
                            print('A conta que você estava logada, foi deletada, Voltando ao menu principal')
                            return True
                        lista.remove(i)
                    os.system('cls')
                    print('Todos os cadastros Deletados')
                    break
                elif opc == 1:
                    try:
                        opc_id = int(input('Digite o id do aluno que deseja encontrar: '))
                    except ValueError:
                        os.system('cls')
                        print('Número inválido. Digite números inteiros')
                        continue
                    for i in lista:
                        if i['id'] == opc_id:
                            print('-'*56) 
                            print('Id:', i['id'])
                            print('Nome:', i['nome'])
                            id_en = True
                if not id_en:
                        os.system('cls')
                        print('Id não encontrado. Tente Novamente')
                        continue
        else:
            os.system('cls')
            print('Senha incorreta, Volte ao menu')
            break
#=================================================================================
#=================================================================================
def deletar_aluno(lista):
    os.system('cls')
    while True:
        print('-'*56)
        print('-'*15, 'GERÊNCIAMENTO DE ALUNOS', '-'*15)
        print('-'*56)  
        print('Qual método deseja utilizar para deletar?: ')
        print('1- Deletar o cadastro do alundo por id')
        print('2- Deletar todos os cadastrados de um vez')
        print('3- Voltar ao menu de gerenciamento')
        try:
            opc = int(input('>>> '))
        except ValueError:
            os.system('cls')
            print('Número inválido. Digite um número inteiro')
        if opc not in [1,2,3]:
            os.system('cls')
            print('Digite uma das opções por favor')
            continue
        else:
            if opc == 3:
                break
            elif opc == 2:
                os.system('cls')
                for i in lista:
                    print('-'*56)
                    print('Id:', i['id'])
                    print('Nome:', i['nome'])
                    print('Idade:', i['idade'])
                    print('Curso:', i['curso'])
                    print('Polo:', i['polo'])
                    lista.remove(i)
                os.system('cls')
                print('Todos os cadastros Deletados')
                break
            elif opc == 1:
                try:
                    opc_id = int(input('Digite o id do aluno que deseja encontrar: '))
                except ValueError:
                    print('Número inválido. Digite números inteiros')
                    continue
                os.system('cls')
                for i in lista:
                    if i['id'] == opc_id:
                        print('-'*56)
                        print('Id:', i['id'])
                        print('Nome:', i['nome'])
                        print('Idade:', i['idade'])
                        print('Curso:', i['curso'])
                        print('Polo:', i['polo'])
                        id_en = True
            if not id_en:
                    os.system('cls')
                    print('Id não encontrado. Tente Novamente')
                    continue