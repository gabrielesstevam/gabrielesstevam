#Este arquivo serve ppara testar na prática a pesquisa binária

import os

def list_desenv():
    list = []
    i = 0
    while len(list) <= 4999:
        list.append(i)
        i += 1
    return list

def search_bin(list, num, mode):
    tentativas = 0
    if mode == 1:
        for i in list:
            tentativas += 1
            print(i)
            if i == num:
                if tentativas == 1 :
                    print('=========================')
                    print("O algortimo acertou o número", i,"com", tentativas , "tentativa")
                    break
                else :
                    print('=========================')
                    print("O algortimo acertou o número ", i," com ", tentativas, "tentativas")
                    break
            else:
                continue
    elif mode == 2:
        min = 0
        max = len(list) - 1
        while min <= max:
            meio = (min + max)// 2
            chute = list[meio]
            tentativas += 1
            if chute == num:
                if tentativas == 1 :
                    print('=========================')
                    print("O algortimo acertou o número", chute,"com", tentativas, "tentativa")
                else :
                    print('=========================')
                    print("O algortimo acertou o número ", chute," com ", tentativas, "tentativas")
                break
            elif chute < num:
                print(chute)
                min = chute + 1
            elif chute > num:
                print(chute)
                max = chute - 1
    return

while True:
    os.system('cls')
    print('=========================')
    list = list_desenv()
    print("a lista tem ", len(list)," números")
    print('=========================')
    print('1- Pesquisa normal')
    print('2- Pesquisa bínaria')
    escolha = int(input('Escolha o modo de pesquisa: '))
    print('=========================')
    if escolha not in (1, 2):
        print('Escolha uma das opções')
        continue
    else:
        try:
            number = int(input('escolha um número inteiro maior que 0 e menor que 5000: '))
            print('=========================')
        except:
            print('Escolha um número inteiro por favor')
            continue
        else:
            break
search_bin(list, number, escolha)

